# Frontend App
This is the placeholder for the React or Next.js frontend.